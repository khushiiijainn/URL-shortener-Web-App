// src/utils/logger.js

const API_URL = "https://backend.affordmed.com/logs/";

export const logEvent = async ({ level, pkg, message }) => {
  const logPayload = {
    stack: "frontend",
    level,
    package: pkg,
    message
  };

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(logPayload)
    });

    if (!response.ok) {
      console.error("Logger failed:", response.statusText);
    }
  } catch (err) {
    console.error("Logger exception:", err);
  }
};
