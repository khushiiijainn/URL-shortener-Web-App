# 🔗 URL Shortener Full-Stack Application

A modern, full-featured URL shortener built with React, Node.js, Express, and MongoDB. Transform long URLs into short, shareable links with click tracking, custom aliases, and analytics.

![URL Shortener Demo](https://img.shields.io/badge/Demo-Live-green)
![Build Status](https://img.shields.io/badge/build-passing-brightgreen)
![License](https://img.shields.io/badge/license-MIT-blue)

## ✨ Features

- **🎨 Modern React Frontend**: Clean, responsive UI with gradient design
- **⚡ Fast Backend API**: Express.js with RESTful endpoints
- **📊 Click Analytics**: Real-time tracking and statistics
- **🔒 Custom Aliases**: User-defined short codes
- **⏰ URL Expiration**: Automatic cleanup of expired links
- **📱 Mobile Responsive**: Works perfectly on all devices
- **🏷️ Tagging System**: Organize URLs with custom tags
- **🔄 URL Validation**: Comprehensive input validation
- **💾 Data Persistence**: MongoDB with robust schema design
- **🚀 Production Ready**: Rate limiting, error handling, logging

## 🏗️ Architecture

```
url-shortener-fullstack/
├── frontend/              # React application
│   ├── src/
│   │   ├── App.js        # Main React component
│   │   ├── App.css       # Styling
│   │   └── index.js      # React entry point
│   ├── public/
│   └── package.json
├── backend/               # Node.js API server
│   ├── config/
│   │   └── database.js   # MongoDB connection
│   ├── models/
│   │   └── Url.js        # URL schema/model
│   ├── routes/
│   │   └── urlRoutes.js  # API endpoints
│   ├── server.js         # Express server
│   └── package.json
└── README.md
```

## 🚀 Quick Start

### Prerequisites

- Node.js 16+ 
- MongoDB (local or MongoDB Atlas)
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd url-shortener-fullstack
   ```

2. **Backend Setup**
   ```bash
   cd backend
   npm install
   cp .env.example .env
   # Edit .env with your MongoDB connection string
   npm run dev
   ```

3. **Frontend Setup** (New terminal)
   ```bash
   cd frontend
   npm install
   npm start
   ```

4. **Open your browser**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000

## 🔧 Configuration

### Backend Environment Variables

Create `backend/.env` file:

```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/urlshortener
BASE_URL=http://localhost:5000
FRONTEND_URL=http://localhost:3000
```

### Frontend Environment Variables (Optional)

Create `frontend/.env` file:

```env
REACT_APP_API_URL=http://localhost:5000/api
```

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/shorten` | Create short URL |
| GET | `/api/urls` | Get all URLs (paginated) |
| GET | `/api/urls/:id` | Get specific URL |
| PUT | `/api/urls/:id` | Update URL |
| DELETE | `/api/urls/:id` | Delete URL |
| GET | `/:shortCode` | Redirect to original URL |
| GET | `/api/analytics/:shortCode` | Get URL analytics |

### Example API Usage

**Create Short URL:**
```bash
curl -X POST http://localhost:5000/api/shorten \
  -H "Content-Type: application/json" \
  -d '{
    "originalUrl": "https://www.example.com/very-long-url",
    "customAlias": "my-link",
    "tags": "example,test"
  }'
```

**Response:**
```json
{
  "success": true,
  "data": {
    "_id": "...",
    "originalUrl": "https://www.example.com/very-long-url",
    "shortCode": "my-link",
    "shortUrl": "http://localhost:5000/my-link",
    "clicks": 0,
    "createdAt": "2025-09-01T10:30:00.000Z",
    "expiresAt": "2026-09-01T10:30:00.000Z"
  }
}
```

## 🎨 Frontend Features

- **URL Input Form**: Validate and shorten URLs
- **Copy to Clipboard**: One-click sharing
- **URL History**: View all shortened URLs
- **Real-time Stats**: Click tracking display
- **Responsive Design**: Mobile-first approach
- **Error Handling**: User-friendly error messages
- **Loading States**: Better UX during API calls

## 💾 Database Schema

```javascript
{
  originalUrl: String,      // Long URL to shorten
  shortCode: String,        // Unique identifier (indexed)
  shortUrl: String,         // Complete short URL
  clicks: Number,           // Click counter
  createdAt: Date,          // Creation timestamp
  expiresAt: Date,          // Expiration date (TTL)
  customAlias: Boolean,     // Whether user defined the alias
  isActive: Boolean,        // Active status
  tags: [String],           // Organization tags
  metadata: {               // Request metadata
    userAgent: String,
    ip: String,
    referer: String
  }
}
```

## 🚀 Production Deployment

### Backend Deployment (Heroku/Railway/DigitalOcean)

1. Set environment variables:
   ```env
   NODE_ENV=production
   MONGODB_URI=mongodb+srv://...
   BASE_URL=https://your-api-domain.com
   FRONTEND_URL=https://your-frontend-domain.com
   ```

2. Build and deploy backend

### Frontend Deployment (Vercel/Netlify)

1. Build the React app:
   ```bash
   cd frontend
   npm run build
   ```

2. Deploy the `build` folder

3. Set environment variable:
   ```env
   REACT_APP_API_URL=https://your-api-domain.com/api
   ```

## 🧪 Testing

### Backend Testing
```bash
cd backend
npm test  # Run API tests
```

### Frontend Testing
```bash
cd frontend
npm test  # Run React component tests
```

## 🔒 Security Features

- **Rate Limiting**: Prevents abuse (100 requests/15 minutes)
- **Input Validation**: Comprehensive URL and data validation
- **CORS Protection**: Configured for frontend domain
- **Error Handling**: Secure error messages
- **Request Logging**: Track API usage
- **MongoDB Injection Prevention**: Parameterized queries

## 📈 Performance Optimizations

- **Database Indexing**: Optimized queries on shortCode, originalUrl
- **MongoDB TTL**: Automatic cleanup of expired URLs
- **Connection Pooling**: Efficient database connections
- **Frontend Caching**: Local storage for URL history
- **Lazy Loading**: Optimized React component rendering

## 🛠️ Advanced Features

### Custom Short Codes
Users can specify custom aliases instead of random generation.

### Bulk URL Management
Import/export URLs via CSV or API.

### Analytics Dashboard
Detailed click analytics with charts and graphs.

### QR Code Generation
Generate QR codes for short URLs.

### Team Collaboration
Multi-user support with shared URL collections.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [nanoid](https://github.com/ai/nanoid) for secure ID generation
- [Express.js](https://expressjs.com/) for the web framework
- [React](https://reactjs.org/) for the frontend
- [MongoDB](https://www.mongodb.com/) for the database
- [Mongoose](https://mongoosejs.com/) for MongoDB object modeling

## 📞 Support

If you have any questions or need help, please:

1. Check the [Issues](../../issues) page
2. Create a new issue with detailed description
3. Join our community discussions

---

**⭐ Star this repository if you find it helpful!**

Built with ❤️ by [Your Name]
