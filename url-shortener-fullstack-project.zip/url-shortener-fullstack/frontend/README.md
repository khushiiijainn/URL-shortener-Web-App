# URL Shortener Frontend

React-based frontend for the URL shortener application.

## Features

- Modern React with hooks (useState, useEffect)
- Responsive CSS design with gradients
- URL validation and error handling
- Copy to clipboard functionality
- URL history with local storage
- Loading states and user feedback
- Mobile-responsive design

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm start
   ```

3. Build for production:
   ```bash
   npm run build
   ```

## Environment Variables

Create `.env` file:
```env
REACT_APP_API_URL=http://localhost:5000/api
```

## Dependencies

- React 18.3.1
- React DOM 18.3.1
- React Scripts 5.0.1

## Browser Compatibility

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
