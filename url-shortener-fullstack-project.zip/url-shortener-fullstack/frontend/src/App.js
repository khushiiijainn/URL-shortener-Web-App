import React, { useState, useEffect } from 'react';
import './App.css';

// API configuration
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Mock API functions (for development without backend)
const mockAPI = {
  generateShortCode: () => {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  },

  isValidUrl: (string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      try {
        new URL('https://' + string);
        return true;
      } catch (_) {
        return false;
      }
    }
  },

  normalizeUrl: (url) => {
    try {
      return new URL(url).toString();
    } catch (_) {
      try {
        return new URL('https://' + url).toString();
      } catch (_) {
        return url;
      }
    }
  },

  shortenUrl: async (originalUrl) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (!mockAPI.isValidUrl(originalUrl)) {
          reject(new Error('Invalid URL format'));
          return;
        }

        const shortCode = mockAPI.generateShortCode();
        const urlData = {
          id: Date.now().toString(),
          originalUrl: mockAPI.normalizeUrl(originalUrl),
          shortCode,
          shortUrl: `https://short.ly/${shortCode}`,
          clicks: 0,
          createdAt: new Date().toISOString()
        };

        const existingUrls = JSON.parse(localStorage.getItem('urlHistory') || '[]');
        existingUrls.unshift(urlData);
        localStorage.setItem('urlHistory', JSON.stringify(existingUrls));

        resolve(urlData);
      }, 1000);
    });
  },

  getAllUrls: () => {
    return JSON.parse(localStorage.getItem('urlHistory') || '[]');
  },

  deleteUrl: (id) => {
    const existingUrls = JSON.parse(localStorage.getItem('urlHistory') || '[]');
    const filteredUrls = existingUrls.filter(url => url.id !== id);
    localStorage.setItem('urlHistory', JSON.stringify(filteredUrls));
    return filteredUrls;
  }
};

// Real API functions (use when backend is available)
const realAPI = {
  shortenUrl: async (originalUrl) => {
    const response = await fetch(`${API_BASE_URL}/shorten`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ originalUrl })
    });

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.message);
    }

    return data.data;
  },

  getAllUrls: async () => {
    const response = await fetch(`${API_BASE_URL}/urls`);
    const data = await response.json();
    return data.success ? data.data : [];
  },

  deleteUrl: async (id) => {
    const response = await fetch(`${API_BASE_URL}/urls/${id}`, {
      method: 'DELETE'
    });
    const data = await response.json();
    return data.success;
  }
};

function App() {
  const [url, setUrl] = useState('');
  const [shortenedUrl, setShortenedUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [urlHistory, setUrlHistory] = useState([]);
  const [useMockAPI, setUseMockAPI] = useState(true);

  const api = useMockAPI ? mockAPI : realAPI;

  useEffect(() => {
    loadUrlHistory();
  }, []);

  const loadUrlHistory = async () => {
    try {
      const urls = useMockAPI ? api.getAllUrls() : await api.getAllUrls();
      setUrlHistory(urls);
    } catch (err) {
      console.error('Failed to load URL history:', err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!url.trim()) return;

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const result = await api.shortenUrl(url);
      setShortenedUrl(result);
      setSuccess('URL shortened successfully!');
      setUrl('');
      await loadUrlHistory();
    } catch (err) {
      setError(err.message || 'Failed to shorten URL');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setSuccess('Copied to clipboard!');
      setTimeout(() => setSuccess(''), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const handleDelete = async (id) => {
    try {
      if (useMockAPI) {
        api.deleteUrl(id);
      } else {
        await api.deleteUrl(id);
      }
      await loadUrlHistory();
      setSuccess('URL deleted successfully!');
    } catch (err) {
      setError('Failed to delete URL');
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="app">
      <div className="container">
        <header className="header">
          <h1>URL Shortener</h1>
          <p>Transform long URLs into short, shareable links</p>
          <div className="api-toggle">
            <label>
              <input
                type="checkbox"
                checked={useMockAPI}
                onChange={(e) => setUseMockAPI(e.target.checked)}
              />
              Use Mock API (for demo)
            </label>
          </div>
        </header>

        <main className="main">
          <form onSubmit={handleSubmit} className="url-form">
            <div className="input-group">
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="Enter your long URL here..."
                className="url-input"
                disabled={loading}
                required
              />
              <button 
                type="submit" 
                className="shorten-btn"
                disabled={loading || !url.trim()}
              >
                {loading ? 'Shortening...' : 'Shorten URL'}
              </button>
            </div>
          </form>

          {error && <div className="message error-message">{error}</div>}
          {success && <div className="message success-message">{success}</div>}

          {shortenedUrl && (
            <div className="result-card">
              <h3>Your shortened URL:</h3>
              <div className="url-result">
                <div className="url-group">
                  <label>Original URL:</label>
                  <span className="original-url">{shortenedUrl.originalUrl}</span>
                </div>
                <div className="url-group">
                  <label>Short URL:</label>
                  <div className="short-url-container">
                    <span className="short-url">{shortenedUrl.shortUrl}</span>
                    <button 
                      onClick={() => copyToClipboard(shortenedUrl.shortUrl)}
                      className="copy-btn"
                    >
                      Copy
                    </button>
                  </div>
                </div>
                <div className="url-stats">
                  <span>Clicks: {shortenedUrl.clicks}</span>
                  <span>Created: {formatDate(shortenedUrl.createdAt)}</span>
                </div>
              </div>
            </div>
          )}

          {urlHistory.length > 0 && (
            <div className="history-section">
              <h3>URL History</h3>
              <div className="url-list">
                {urlHistory.map((urlItem) => (
                  <div key={urlItem.id} className="url-item">
                    <div className="url-item-content">
                      <div className="url-group">
                        <label>Original:</label>
                        <span className="original-url" title={urlItem.originalUrl}>
                          {urlItem.originalUrl.length > 50 
                            ? urlItem.originalUrl.substring(0, 50) + '...' 
                            : urlItem.originalUrl}
                        </span>
                      </div>
                      <div className="url-group">
                        <label>Short:</label>
                        <div className="short-url-container">
                          <span className="short-url">{urlItem.shortUrl}</span>
                          <button 
                            onClick={() => copyToClipboard(urlItem.shortUrl)}
                            className="copy-btn small"
                          >
                            Copy
                          </button>
                        </div>
                      </div>
                      <div className="url-stats">
                        <span>Clicks: {urlItem.clicks}</span>
                        <span>Created: {formatDate(urlItem.createdAt)}</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => handleDelete(urlItem.id)}
                      className="delete-btn"
                    >
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;