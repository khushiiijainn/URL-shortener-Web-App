const mongoose = require('mongoose');
const { nanoid } = require('nanoid');

const urlSchema = new mongoose.Schema({
  originalUrl: {
    type: String,
    required: [true, 'Original URL is required'],
    trim: true,
    validate: {
      validator: function(v) {
        // Basic URL validation
        try {
          new URL(v);
          return true;
        } catch (err) {
          return false;
        }
      },
      message: 'Please provide a valid URL'
    }
  },
  shortCode: {
    type: String,
    required: true,
    unique: true,
    default: () => nanoid(6),
    minlength: [4, 'Short code must be at least 4 characters'],
    maxlength: [12, 'Short code cannot exceed 12 characters'],
    match: [/^[a-zA-Z0-9_-]+$/, 'Short code can only contain letters, numbers, underscores, and hyphens']
  },
  shortUrl: {
    type: String,
    required: true
  },
  clicks: {
    type: Number,
    default: 0,
    min: [0, 'Clicks cannot be negative']
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  expiresAt: {
    type: Date,
    default: () => new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
    index: { expireAfterSeconds: 0 } // MongoDB TTL index
  },
  customAlias: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  tags: [{
    type: String,
    trim: true
  }],
  metadata: {
    userAgent: String,
    ip: String,
    referer: String
  }
}, {
  timestamps: true, // Adds createdAt and updatedAt automatically
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for performance
urlSchema.index({ shortCode: 1 }); // Primary lookup index
urlSchema.index({ originalUrl: 1 }); // For duplicate detection
urlSchema.index({ createdAt: -1 }); // For sorting by creation date
urlSchema.index({ clicks: -1 }); // For sorting by popularity
urlSchema.index({ isActive: 1 }); // For filtering active URLs

// Virtual for age calculation
urlSchema.virtual('age').get(function() {
  return Date.now() - this.createdAt;
});

// Virtual for days until expiration
urlSchema.virtual('daysUntilExpiration').get(function() {
  const msPerDay = 24 * 60 * 60 * 1000;
  return Math.ceil((this.expiresAt - Date.now()) / msPerDay);
});

// Pre-save middleware to generate shortUrl
urlSchema.pre('save', function(next) {
  if (this.isNew || this.isModified('shortCode')) {
    this.shortUrl = `${process.env.BASE_URL || 'http://localhost:5000'}/${this.shortCode}`;
  }
  next();
});

// Static method to find non-expired URLs
urlSchema.statics.findActive = function() {
  return this.find({
    isActive: true,
    $or: [
      { expiresAt: { $gt: new Date() } },
      { expiresAt: { $exists: false } }
    ]
  });
};

// Instance method to increment clicks
urlSchema.methods.incrementClicks = async function() {
  this.clicks += 1;
  return this.save();
};

// Instance method to check if expired
urlSchema.methods.isExpired = function() {
  return this.expiresAt && this.expiresAt < new Date();
};

// Instance method to deactivate URL
urlSchema.methods.deactivate = async function() {
  this.isActive = false;
  return this.save();
};

// Static method to clean up expired URLs
urlSchema.statics.cleanupExpired = async function() {
  const result = await this.deleteMany({
    expiresAt: { $lt: new Date() },
    isActive: false
  });
  console.log(`🧹 Cleaned up ${result.deletedCount} expired URLs`);
  return result;
};

// Error handling for duplicate key
urlSchema.post('save', function(error, doc, next) {
  if (error.name === 'MongoError' && error.code === 11000) {
    next(new Error('Short code already exists. Please try again.'));
  } else {
    next(error);
  }
});

module.exports = mongoose.model('Url', urlSchema);