const express = require('express');
const validator = require('validator');
const { nanoid } = require('nanoid');
const Url = require('../models/Url');

const router = express.Router();

// @desc    Create short URL
// @route   POST /api/shorten
// @access  Public
router.post('/shorten', async (req, res) => {
  try {
    let { originalUrl, customAlias, tags, expiresIn } = req.body;

    // Validate required fields
    if (!originalUrl) {
      return res.status(400).json({
        success: false,
        message: 'Original URL is required'
      });
    }

    // Normalize URL - add https:// if no protocol
    if (!/^https?:\/\//i.test(originalUrl)) {
      originalUrl = 'https://' + originalUrl;
    }

    // Validate URL format
    if (!validator.isURL(originalUrl, { 
      require_protocol: true,
      protocols: ['http', 'https']
    })) {
      return res.status(400).json({
        success: false,
        message: 'Invalid URL format. Please provide a valid HTTP or HTTPS URL.'
      });
    }

    // Check if URL already exists (optional: return existing one)
    const existingUrl = await Url.findOne({ 
      originalUrl,
      isActive: true,
      expiresAt: { $gt: new Date() }
    });

    if (existingUrl) {
      return res.status(200).json({
        success: true,
        data: existingUrl,
        message: 'URL already exists'
      });
    }

    // Generate or validate custom alias
    let shortCode;
    if (customAlias) {
      // Validate custom alias
      if (!/^[a-zA-Z0-9_-]{4,12}$/.test(customAlias)) {
        return res.status(400).json({
          success: false,
          message: 'Custom alias must be 4-12 characters long and contain only letters, numbers, underscores, and hyphens.'
        });
      }

      // Check if custom alias already exists
      const existingAlias = await Url.findOne({ shortCode: customAlias });
      if (existingAlias) {
        return res.status(400).json({
          success: false,
          message: 'Custom alias already exists. Please choose a different one.'
        });
      }

      shortCode = customAlias;
    } else {
      // Generate unique short code
      let attempts = 0;
      const maxAttempts = 10;

      do {
        shortCode = nanoid(6);
        attempts++;
      } while (
        attempts < maxAttempts && 
        await Url.findOne({ shortCode })
      );

      if (attempts >= maxAttempts) {
        return res.status(500).json({
          success: false,
          message: 'Unable to generate unique short code. Please try again.'
        });
      }
    }

    // Calculate expiration date
    let expiresAt = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000); // Default: 1 year
    if (expiresIn) {
      const expiresInMs = parseInt(expiresIn) * 24 * 60 * 60 * 1000; // Convert days to ms
      if (expiresInMs > 0 && expiresInMs <= 365 * 24 * 60 * 60 * 1000) {
        expiresAt = new Date(Date.now() + expiresInMs);
      }
    }

    // Create URL document
    const urlDoc = await Url.create({
      originalUrl,
      shortCode,
      shortUrl: `${process.env.BASE_URL || 'http://localhost:5000'}/${shortCode}`,
      customAlias: !!customAlias,
      tags: tags ? tags.split(',').map(tag => tag.trim()).filter(tag => tag) : [],
      expiresAt,
      metadata: {
        userAgent: req.headers['user-agent'],
        ip: req.ip || req.connection.remoteAddress,
        referer: req.headers.referer || req.headers.referrer
      }
    });

    // Return success response
    res.status(201).json({
      success: true,
      data: urlDoc,
      message: 'URL shortened successfully'
    });

  } catch (error) {
    console.error('Error shortening URL:', error);

    // Handle specific MongoDB errors
    if (error.name === 'ValidationError') {
      const errors = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors
      });
    }

    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: 'Short code already exists. Please try again.'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @desc    Get all URLs with pagination and filters
// @route   GET /api/urls
// @access  Public
router.get('/urls', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 50,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      search,
      tags
    } = req.query;

    // Build filter object
    const filter = { isActive: true };

    if (search) {
      filter.$or = [
        { originalUrl: { $regex: search, $options: 'i' } },
        { shortCode: { $regex: search, $options: 'i' } }
      ];
    }

    if (tags) {
      const tagArray = tags.split(',').map(tag => tag.trim());
      filter.tags = { $in: tagArray };
    }

    // Build sort object
    const sort = {};
    sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Calculate pagination
    const pageNum = parseInt(page);
    const limitNum = Math.min(parseInt(limit), 100); // Max 100 per page
    const skip = (pageNum - 1) * limitNum;

    // Execute query
    const [urls, totalCount] = await Promise.all([
      Url.find(filter)
        .sort(sort)
        .skip(skip)
        .limit(limitNum)
        .select('-metadata -__v'), // Exclude sensitive metadata
      Url.countDocuments(filter)
    ]);

    // Calculate pagination info
    const totalPages = Math.ceil(totalCount / limitNum);
    const hasNextPage = pageNum < totalPages;
    const hasPrevPage = pageNum > 1;

    res.status(200).json({
      success: true,
      data: urls,
      pagination: {
        currentPage: pageNum,
        totalPages,
        totalCount,
        limit: limitNum,
        hasNextPage,
        hasPrevPage
      },
      message: `Found ${urls.length} URLs`
    });

  } catch (error) {
    console.error('Error fetching URLs:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @desc    Get URL by ID
// @route   GET /api/urls/:id
// @access  Public
router.get('/urls/:id', async (req, res) => {
  try {
    const { id } = req.params;

    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid URL ID format'
      });
    }

    const url = await Url.findById(id).select('-metadata -__v');

    if (!url) {
      return res.status(404).json({
        success: false,
        message: 'URL not found'
      });
    }

    res.status(200).json({
      success: true,
      data: url
    });

  } catch (error) {
    console.error('Error fetching URL:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @desc    Update URL
// @route   PUT /api/urls/:id
// @access  Public
router.put('/urls/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { tags, isActive } = req.body;

    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid URL ID format'
      });
    }

    const updateData = {};
    if (tags !== undefined) {
      updateData.tags = typeof tags === 'string' 
        ? tags.split(',').map(tag => tag.trim()).filter(tag => tag)
        : tags;
    }
    if (isActive !== undefined) {
      updateData.isActive = Boolean(isActive);
    }

    const url = await Url.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    ).select('-metadata -__v');

    if (!url) {
      return res.status(404).json({
        success: false,
        message: 'URL not found'
      });
    }

    res.status(200).json({
      success: true,
      data: url,
      message: 'URL updated successfully'
    });

  } catch (error) {
    console.error('Error updating URL:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @desc    Delete URL
// @route   DELETE /api/urls/:id
// @access  Public
router.delete('/urls/:id', async (req, res) => {
  try {
    const { id } = req.params;

    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid URL ID format'
      });
    }

    const url = await Url.findByIdAndDelete(id);

    if (!url) {
      return res.status(404).json({
        success: false,
        message: 'URL not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'URL deleted successfully',
      data: { id: url._id }
    });

  } catch (error) {
    console.error('Error deleting URL:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @desc    Redirect to original URL and track clicks
// @route   GET /:shortCode
// @access  Public
router.get('/:shortCode', async (req, res) => {
  try {
    const { shortCode } = req.params;

    // Validate short code format
    if (!/^[a-zA-Z0-9_-]+$/.test(shortCode)) {
      return res.status(404).json({
        success: false,
        message: 'Invalid short code format'
      });
    }

    // Find URL by short code
    const url = await Url.findOne({ 
      shortCode,
      isActive: true
    });

    if (!url) {
      return res.status(404).json({
        success: false,
        message: 'Short URL not found'
      });
    }

    // Check if expired
    if (url.isExpired()) {
      await url.deactivate();
      return res.status(410).json({
        success: false,
        message: 'This short URL has expired'
      });
    }

    // Increment click count asynchronously
    setImmediate(async () => {
      try {
        await url.incrementClicks();
      } catch (error) {
        console.error('Error incrementing clicks:', error);
      }
    });

    // Redirect to original URL
    console.log(`🔗 Redirecting ${shortCode} -> ${url.originalUrl}`);
    res.redirect(301, url.originalUrl);

  } catch (error) {
    console.error('Error redirecting:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @desc    Get analytics for a short URL
// @route   GET /api/analytics/:shortCode
// @access  Public
router.get('/analytics/:shortCode', async (req, res) => {
  try {
    const { shortCode } = req.params;

    const url = await Url.findOne({ shortCode }).select('-metadata -__v');

    if (!url) {
      return res.status(404).json({
        success: false,
        message: 'Short URL not found'
      });
    }

    const analytics = {
      shortCode: url.shortCode,
      originalUrl: url.originalUrl,
      shortUrl: url.shortUrl,
      clicks: url.clicks,
      createdAt: url.createdAt,
      expiresAt: url.expiresAt,
      isActive: url.isActive,
      isExpired: url.isExpired(),
      daysUntilExpiration: url.daysUntilExpiration,
      tags: url.tags || []
    };

    res.status(200).json({
      success: true,
      data: analytics
    });

  } catch (error) {
    console.error('Error fetching analytics:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

module.exports = router;