# URL Shortener Backend

Node.js/Express API server for the URL shortener application.

## Features

- RESTful API with Express.js
- MongoDB with Mongoose ODM
- URL validation and sanitization
- Click tracking and analytics
- Custom aliases support
- Rate limiting and security
- Comprehensive error handling
- Request logging

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Set up environment variables:
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. Start development server:
   ```bash
   npm run dev
   ```

4. Start production server:
   ```bash
   npm start
   ```

## API Endpoints

- POST `/api/shorten` - Create short URL
- GET `/api/urls` - Get all URLs
- GET `/api/urls/:id` - Get specific URL
- DELETE `/api/urls/:id` - Delete URL
- GET `/:shortCode` - Redirect to original URL

## Environment Variables

Required variables in `.env`:
- `PORT` - Server port (default: 5000)
- `MONGODB_URI` - MongoDB connection string
- `BASE_URL` - Base URL for short links
- `FRONTEND_URL` - Frontend URL for CORS

## Dependencies

- express: ^4.19.2
- mongoose: ^8.5.2
- cors: ^2.8.5
- dotenv: ^16.4.5
- nanoid: ^3.3.7
- validator: ^13.12.0
- express-rate-limit: ^7.4.0
