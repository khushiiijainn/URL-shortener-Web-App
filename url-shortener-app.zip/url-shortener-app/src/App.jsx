import React, { useState } from 'react';
import {
  Container, TextField, Button, Typography, Box, Grid, Paper
} from '@mui/material';
import { v4 as uuidv4 } from 'uuid';

const isValidURL = (url) => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

const logEvent = (event) => {
  // Simulating custom logging middleware
  console.info("LOG:", event);
};

function App() {
  const [inputs, setInputs] = useState([{ url: '', validity: '', shortcode: '' }]);
  const [shortened, setShortened] = useState([]);
  const [errors, setErrors] = useState([]);

  const handleChange = (index, field, value) => {
    const newInputs = [...inputs];
    newInputs[index][field] = value;
    setInputs(newInputs);
  };

  const addInput = () => {
    if (inputs.length >= 5) return;
    setInputs([...inputs, { url: '', validity: '', shortcode: '' }]);
  };

  const generateShortcode = () => uuidv4().split('-')[0];

  const handleSubmit = () => {
    const newErrors = [];
    const newShortened = [];

    inputs.forEach(({ url, validity, shortcode }, idx) => {
      if (!isValidURL(url)) {
        newErrors.push(`Input ${idx + 1}: Invalid URL`);
        return;
      }

      let finalShort = shortcode || generateShortcode();
      let exists = newShortened.find((s) => s.shortcode === finalShort);
      if (exists) {
        newErrors.push(`Input ${idx + 1}: Duplicate shortcode "${finalShort}"`);
        return;
      }

      const duration = validity ? parseInt(validity) : 30;
      if (isNaN(duration) || duration <= 0) {
        newErrors.push(`Input ${idx + 1}: Invalid validity`);
        return;
      }

      const shortUrl = `https://short.ly/${finalShort}`;
      newShortened.push({ url, shortcode: finalShort, shortUrl, validity: duration });

      logEvent(`Shortened ${url} to ${shortUrl} for ${duration} mins`);
    });

    setErrors(newErrors);
    if (newErrors.length === 0) setShortened(newShortened);
  };

  return (
    <Container maxWidth="md" sx={{ mt: 5 }}>
      <Typography variant="h4" gutterBottom>URL Shortener</Typography>
      {inputs.map((input, index) => (
        <Paper key={index} sx={{ p: 2, mb: 2 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth label="Long URL" value={input.url}
                onChange={(e) => handleChange(index, 'url', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={3}>
              <TextField
                fullWidth label="Custom Shortcode (Optional)" value={input.shortcode}
                onChange={(e) => handleChange(index, 'shortcode', e.target.value)}
              />
            </Grid>
            <Grid item xs={12} sm={3}>
              <TextField
                fullWidth label="Validity (mins)" value={input.validity}
                onChange={(e) => handleChange(index, 'validity', e.target.value)}
              />
            </Grid>
          </Grid>
        </Paper>
      ))}
      <Box display="flex" justifyContent="space-between" mb={2}>
        <Button variant="outlined" onClick={addInput} disabled={inputs.length >= 5}>+ Add URL</Button>
        <Button variant="contained" onClick={handleSubmit}>Shorten</Button>
      </Box>
      {errors.length > 0 && (
        <Box sx={{ mb: 2 }}>
          {errors.map((e, i) => (
            <Typography key={i} color="error">{e}</Typography>
          ))}
        </Box>
      )}
      {shortened.length > 0 && (
        <Box>
          <Typography variant="h6">Shortened URLs:</Typography>
          {shortened.map((s, i) => (
            <Paper key={i} sx={{ p: 1, mt: 1 }}>
              <Typography>Original: {s.url}</Typography>
              <Typography>Short: <a href={s.url} target="_blank" rel="noreferrer">{s.shortUrl}</a></Typography>
              <Typography>Validity: {s.validity} mins</Typography>
            </Paper>
          ))}
        </Box>
      )}
    </Container>
  );
}

export default App;